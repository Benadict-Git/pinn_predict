# Data Dictionary — Phase 1 Outputs

All files below live in `data/processed/`. See `STATUS.md` (project root)
for the full raw-data inventory and known issues; this file documents only
the cleaned/derived outputs.

## observations.csv

One row per real groundwater-level reading. Built by `scripts/merge_datasets.py`.

| Column | Type | Units / range | Source | Missing-value handling |
|---|---|---|---|---|
| `x` | float | longitude, degrees, ~76.4-80.3 | station lat/lon from NWIC files, via `station_table.csv` | rows with no lat/lon dropped |
| `y` | float | latitude, degrees, ~8.1-13.5 | station lat/lon from NWIC files, via `station_table.csv` | rows with no lat/lon dropped |
| `t` | float | days since 1970-01-01 (fractional; telemetry is 6-hourly) | `Data Acquisition Time`, all gwl files | rows with unparseable date dropped |
| `district` | str | one of 38 canonical Tamil Nadu districts | `district_name_mapping.csv` | rows with no district match dropped |
| `h` | float | **depth to water table below ground, meters, positive = deeper** (NOT an absolute hydraulic head elevation — no DEM available to convert to a fixed datum; see STATUS.md) | `gwl_manual_quarterly_*`, `gwl_tel_6_hourly_*` | sentinel values (`999`, `-999.999`, and other `\|value\| >= 200`) dropped; telemetry sign-flipped to match manual convention (STATUS.md issue 1, unconfirmed) |
| `R` | float | recharge proxy, mm/day, >= 0 | derived from rainfall + humidity, see `recharge_daily.csv` below | NaN wherever no humidity reading exists for that (district, date) — **not filled with 0**; ~80% of rows are NaN because most `h` readings predate humidity coverage (2021-07-28) |
| `Q` | float | pumping relative index, unitless, [0, 1] (NOT m3/day — no metered volumes exist in source data) | `pumping_proxy.csv` | always present (all 38 districts covered, 6 via parent-district fallback) |
| `source` | str | `manual_quarterly` or `telemetry_6hourly` | which raw GWL file family the reading came from | n/a |

4,578,824 rows. t range 767.0 .. 20603.8 (1972-02-07 .. 2026-05-30).
**File is 368MB** — mostly because telemetry readings are kept at native
6-hourly resolution (3,753,924 of the rows). Consider temporal
subsampling before Phase 2 training if this is unwieldy; that is a
modeling decision, not made here.

## collocation.csv

Dense synthetic (x, y, t) points for the PDE-residual loss, NOT real
observations. Built by `scripts/build_collocation_grid.py`.

| Column | Type | Units / range | Notes |
|---|---|---|---|
| `x` | float | longitude, degrees | 30 evenly spaced values over the station bounding box |
| `y` | float | latitude, degrees | 30 evenly spaced values over the station bounding box |
| `t` | float | days since 1970-01-01 | 57 monthly steps, 2021-09-01 .. 2026-05-01 |
| `district` | str | nearest-centroid district assignment | **approximate** — no district boundary shapefile exists in `data/raw/`, so this is nearest-station-centroid, not a true polygon lookup; border points may be misassigned |
| `R` | float | mm/day, district-month mean of `recharge_daily.csv` | NaN for the 12 of 38 districts with no humidity station (66.8% of rows have a value) |
| `Q` | float | unitless, [0, 1] | always present, same source as observations.csv |

51,300 rows (30 x 30 spatial x 57 monthly). Time range is deliberately
narrower than observations.csv because R is undefined before humidity
coverage begins (2021-07-28) — extending the collocation grid further
back would require fabricating a recharge value.

## Intermediate files (inputs to the above)

- **district_name_mapping.csv** — 168 rows, every district-name spelling
  variant seen in any raw file mapped to one of 38 canonical districts.
  Columns: `canonical_district`, `lgd_code` (blank for data.gov.in-sourced
  rows, which predate LGD codes), `source_name`, `source`,
  `pre2019_parent_district` (only set for the 6 post-2019-split districts).
- **station_table.csv** — 3,391 rows, keyed on `(Station, canonical_district)`
  — **not** `Station` alone, since 181 station names recur across
  unrelated districts (STATUS.md issue 8). Columns: `Station`,
  `canonical_district`, `latitude`, `longitude`,
  `lat_lon_disagreement_deg` (max spread seen across files for that pair;
  large values mean the same station reported inconsistent coordinates in
  different files — not resolved further, just flagged).
- **rainfall_daily.csv** — station-day rainfall (mm), summed from
  telemetry/manual hourly readings or taken directly from manual daily
  readings. `rainfall_mm` >= 0, capped at 300mm/single-reading before
  daily aggregation (see `clean_rainfall.py` docstring for the sentinel
  values this removes).
- **humidity_daily.csv** — station-day mean relative humidity (%), bounded
  [0, 100] (raw data went up to 1007%, dropped, see `clean_humidity.py`).
- **recharge_daily.csv** — district-day recharge proxy. `et_proxy_mm =
  0.1 * (100 - humidity_pct)` (an uncalibrated linear stand-in for
  Hargreaves ET, which needs temperature data that does not exist in
  `data/raw/`). `recharge_mm = max(rainfall_mm - et_proxy_mm, 0)`, clipped
  at zero since negative recharge is not physical. NaN wherever no
  humidity reading exists for that district-day.
- **well_stats_2018_19.csv** — 32-district (pre-2019-split) snapshot of
  irrigated area and well counts from the three data.gov.in files. Static,
  single year, no time dimension.
- **pumping_proxy.csv** — 38-district `Q_relative_index`, unweighted mean
  of three min-max-normalized components (irrigated area, irrigation well
  count, domestic+industrial well count). **Relative index, not a
  volumetric rate** — there is no metered pumping data anywhere in
  `data/raw/` to calibrate real units. The 6 post-2019-split districts
  copy their parent district's absolute figures verbatim (not split
  proportionally — no data exists to determine a real split), so summing
  this column across all 38 districts double-counts those 6 districts'
  contribution to their parent's original figures.

## Known limitations carried into these outputs (see STATUS.md for full detail)

1. GWL sign convention between manual and telemetry sources is inferred
   from matching median magnitudes, not confirmed by any data dictionary,
   and the Rajya Sabha cross-check shows a large (24.4 percentage point
   mean) unresolved discrepancy.
2. `h` is a depth-below-ground convention, not an absolute head elevation.
   No DEM is added to these Phase 1 outputs to fix this — Phase 2
   (`notebooks/pinn_train.ipynb`) instead fetches ground elevation at
   Kaggle runtime (SRTM API) and derives head as `elev - h` there. See
   STATUS.md's "depth-to-head conversion" and "elev-as-input" entries.
3. `R`'s ET term is a rough proxy in the absence of temperature data or
   ERA5-Land, not a validated evapotranspiration model.
4. `Q` is a static, unitless, single-year (2018-19) relative index, not a
   time-varying volumetric pumping rate.
5. `collocation.csv`'s district assignment is nearest-centroid, not a true
   spatial polygon lookup.
